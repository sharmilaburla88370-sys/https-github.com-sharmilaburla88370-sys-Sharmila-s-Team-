
import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import TextScanner from './components/TextScanner';
import ImageScanner from './components/ImageScanner';
import LiveCoach from './components/LiveCoach';
import ScamLibrary from './components/ScamLibrary';

type View = 'dashboard' | 'text' | 'image' | 'live' | 'library';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onViewChange={setCurrentView} />;
      case 'text':
        return <TextScanner />;
      case 'image':
        return <ImageScanner />;
      case 'live':
        return <LiveCoach />;
      case 'library':
        return <ScamLibrary />;
      default:
        return <Dashboard onViewChange={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <Header currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          {renderView()}
        </div>
      </main>
      <footer className="py-6 border-t border-slate-800 text-center text-slate-500 text-sm">
        &copy; 2024 GuardDog AI. Built for the Hackathon. Protect yourself online.
      </footer>
    </div>
  );
};

export default App;
