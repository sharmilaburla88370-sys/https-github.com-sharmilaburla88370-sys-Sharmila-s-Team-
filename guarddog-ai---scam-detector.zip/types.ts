
export enum ScamCategory {
  PHISHING = 'PHISHING',
  SPOOFING = 'SPOOFING',
  URGENCY = 'URGENCY',
  SOCIAL_ENGINEERING = 'SOCIAL_ENGINEERING',
  FINANCIAL_FRAUD = 'FINANCIAL_FRAUD',
  LEGITIMATE = 'LEGITIMATE'
}

export interface AnalysisResult {
  riskScore: number; // 0 to 100
  category: ScamCategory;
  findings: string[];
  recommendation: string;
  isScam: boolean;
  groundingSources?: Array<{ title: string; uri: string }>;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
