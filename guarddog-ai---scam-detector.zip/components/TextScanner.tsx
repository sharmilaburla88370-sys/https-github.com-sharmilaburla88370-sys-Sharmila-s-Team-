
import React, { useState, useEffect, useRef } from 'react';
import { analyzeTextScam, groundScamQuery } from '../services/geminiService';
import { AnalysisResult } from '../types';

const TextScanner: React.FC = () => {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [grounding, setGrounding] = useState<any>(null);
  const [feedbackSent, setFeedbackSent] = useState(false);
  
  const debounceTimer = useRef<NodeJS.Timeout | null>(null);

  // Real-time scanning effect
  useEffect(() => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    if (text.trim().length < 15) {
      setResult(null);
      setGrounding(null);
      return;
    }

    debounceTimer.current = setTimeout(() => {
      handleScan();
    }, 1000); // 1 second debounce to avoid excessive API calls

    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [text]);

  const handleScan = async () => {
    setLoading(true);
    setFeedbackSent(false);
    try {
      const scanResult = await analyzeTextScam(text);
      setResult(scanResult);
      
      // If high risk, ground it
      if (scanResult.isScam || scanResult.riskScore > 50) {
        const searchResult = await groundScamQuery(text.substring(0, 250));
        setGrounding(searchResult);
      }
    } catch (e) {
      console.error("Auto-scan failed", e);
    } finally {
      setLoading(false);
    }
  };

  const submitFeedback = (correct: boolean) => {
    // In a real app, this would send data to a backend for retraining
    console.log(`User feedback: Verdict was ${correct ? 'Correct' : 'Incorrect'} for text: ${text.substring(0, 50)}...`);
    setFeedbackSent(true);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold text-white">Live Message Scanner</h2>
          {loading && (
            <div className="flex items-center gap-2 text-indigo-400 text-sm font-medium animate-pulse">
              <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              AI is analyzing...
            </div>
          )}
        </div>
        <p className="text-slate-400">Start typing or paste a message. GuardDog scans your input in real-time to provide an instant safety assessment.</p>
      </div>

      <div className="relative group">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste message or URL here (min 15 characters for real-time scan)..."
          className="w-full h-64 bg-slate-900 border border-slate-800 rounded-3xl p-6 text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none transition-all shadow-inner group-hover:border-slate-700"
        ></textarea>
        
        {/* Real-time Risk Meter overlay */}
        {result && (
          <div className="absolute top-4 right-4 flex flex-col items-end">
             <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter mb-1 border ${
                result.riskScore > 70 ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                result.riskScore > 30 ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20' : 
                'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
             }`}>
               Risk: {result.riskScore}%
             </div>
             <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-1000 ${
                    result.riskScore > 70 ? 'bg-red-500' : result.riskScore > 30 ? 'bg-yellow-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${result.riskScore}%` }}
                ></div>
             </div>
          </div>
        )}
      </div>

      {result && (
        <div className="animate-in slide-in-from-top-4 duration-500 space-y-6">
          <div className={`p-8 rounded-3xl border shadow-2xl ${result.isScam ? 'bg-red-950/20 border-red-500/30' : 'bg-emerald-950/20 border-emerald-500/30'}`}>
            <div className="flex items-start justify-between mb-6">
              <div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${result.isScam ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white'}`}>
                  {result.category}
                </span>
                <h3 className="text-2xl font-bold text-white mt-2">
                  {result.isScam ? 'Warning: High Scam Probability' : 'Verification: Likely Safe'}
                </h3>
              </div>
              <div className="text-right">
                <p className="text-slate-500 text-sm mb-1 uppercase tracking-tight">AI Confidence</p>
                <p className={`text-4xl font-black ${result.riskScore > 70 ? 'text-red-500' : result.riskScore > 30 ? 'text-yellow-500' : 'text-emerald-500'}`}>
                  {result.riskScore}%
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01m-.01 4h.01" />
                  </svg>
                  Red Flags Identified
                </h4>
                <ul className="space-y-2">
                  {result.findings.map((finding, i) => (
                    <li key={i} className="text-slate-400 text-sm flex items-start gap-2">
                      <span className="text-indigo-500 mt-1 shrink-0">•</span>
                      {finding}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-5 bg-slate-950/50 rounded-2xl border border-slate-800">
                <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-2">Security Advice</h4>
                <p className="text-slate-300 text-sm leading-relaxed">{result.recommendation}</p>
              </div>

              {/* Feedback Mechanism */}
              <div className="pt-4 border-t border-slate-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p className="text-xs text-slate-500 font-medium">Was this assessment accurate?</p>
                {feedbackSent ? (
                  <span className="text-xs text-emerald-500 font-bold flex items-center gap-1">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Thanks for the feedback!
                  </span>
                ) : (
                  <div className="flex gap-2">
                    <button 
                      onClick={() => submitFeedback(true)}
                      className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-full transition-colors flex items-center gap-1.5"
                    >
                      👍 Yes
                    </button>
                    <button 
                      onClick={() => submitFeedback(false)}
                      className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-full transition-colors flex items-center gap-1.5"
                    >
                      👎 No
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {grounding && grounding.sources.length > 0 && (
            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <svg className="w-5 h-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Real-world Threat Context
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed">{grounding.text}</p>
              <div className="flex flex-wrap gap-2 pt-2">
                {grounding.sources.map((source: any, i: number) => (
                  <a 
                    key={i} 
                    href={source.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600/20 hover:text-indigo-300 text-slate-400 text-xs rounded-lg transition-all border border-slate-700 truncate max-w-[200px]"
                  >
                    {source.title}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {text.length > 0 && text.length < 15 && (
        <p className="text-center text-slate-600 text-xs">
          Keep typing... AI scanning activates at 15 characters.
        </p>
      )}
    </div>
  );
};

export default TextScanner;
