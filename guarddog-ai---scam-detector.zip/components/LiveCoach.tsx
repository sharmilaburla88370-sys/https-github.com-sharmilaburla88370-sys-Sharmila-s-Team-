
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';

const LiveCoach: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState<string[]>([]);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'listening'>('idle');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionPromiseRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const startSession = async () => {
    setStatus('connecting');
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    const session = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-09-2025',
      callbacks: {
        onopen: () => {
          setStatus('listening');
          setIsActive(true);
          const source = audioContextRef.current!.createMediaStreamSource(stream);
          const processor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
            const pcmBlob = {
              data: encode(new Uint8Array(int16.buffer)),
              mimeType: 'audio/pcm;rate=16000',
            };
            sessionPromiseRef.current?.then((s: any) => s.sendRealtimeInput({ media: pcmBlob }));
          };
          source.connect(processor);
          processor.connect(audioContextRef.current!.destination);
        },
        onmessage: async (msg) => {
          if (msg.serverContent?.outputTranscription) {
            setTranscription(prev => [...prev.slice(-4), `Model: ${msg.serverContent!.outputTranscription!.text}`]);
          }
          if (msg.serverContent?.inputTranscription) {
             setTranscription(prev => [...prev.slice(-4), `You: ${msg.serverContent!.inputTranscription!.text}`]);
          }

          const audioBase64 = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audioBase64) {
            const outCtx = outputAudioContextRef.current!;
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outCtx.currentTime);
            const buffer = await decodeAudioData(decode(audioBase64), outCtx, 24000, 1);
            const source = outCtx.createBufferSource();
            source.buffer = buffer;
            source.connect(outCtx.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            sourcesRef.current.add(source);
            source.onended = () => sourcesRef.current.delete(source);
          }
        },
        onerror: (e) => console.error("Live error", e),
        onclose: () => {
          setIsActive(false);
          setStatus('idle');
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        systemInstruction: "You are 'ScamCoach'. Act as a sophisticated scammer (e.g., tech support, lottery, IRS agent) to train the user. Start the conversation. After 3-4 turns, stop acting and explain to the user what tactics you were using and how to spot them. Be friendly but realistic.",
        outputAudioTranscription: {},
        inputAudioTranscription: {},
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } }
      }
    });

    sessionPromiseRef.current = Promise.resolve(session);
  };

  const stopSession = () => {
    sessionPromiseRef.current?.then((s: any) => s.close());
    setIsActive(false);
    setStatus('idle');
    audioContextRef.current?.close();
    outputAudioContextRef.current?.close();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-white">Interactive Scam Coach</h2>
        <p className="text-slate-400">Practice your defense against high-pressure voice scams. Our AI will roleplay a scammer so you can learn to spot red flags in real-time conversations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 flex flex-col items-center justify-center space-y-6">
          <div className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500 ${isActive ? 'bg-indigo-600 shadow-[0_0_50px_rgba(79,70,229,0.4)] scale-110' : 'bg-slate-800'}`}>
            <svg className={`w-16 h-16 ${isActive ? 'text-white' : 'text-slate-600'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            {isActive && (
              <div className="absolute inset-0 rounded-full border-4 border-indigo-400 animate-ping opacity-20"></div>
            )}
          </div>

          <div className="text-center">
            <h3 className="text-xl font-bold text-white">
              {status === 'idle' ? 'Ready to Start' : status === 'connecting' ? 'Connecting to Coach...' : 'Listening...'}
            </h3>
            <p className="text-slate-500 text-sm mt-1">Practice identifying urgency and authority tactics</p>
          </div>

          {!isActive ? (
            <button
              onClick={startSession}
              className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl transition-all shadow-xl"
            >
              Start Training Session
            </button>
          ) : (
            <button
              onClick={stopSession}
              className="px-10 py-4 bg-red-600 hover:bg-red-500 text-white font-bold rounded-2xl transition-all shadow-xl"
            >
              End Session
            </button>
          )}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h4 className="text-slate-300 font-bold uppercase tracking-widest text-xs">Live Transcription</h4>
            <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-indigo-500 animate-pulse' : 'bg-slate-700'}`}></span>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto max-h-[300px] no-scrollbar">
            {transcription.length === 0 ? (
              <p className="text-slate-600 text-sm italic">Press start to begin roleplay...</p>
            ) : (
              transcription.map((line, i) => (
                <div key={i} className={`p-3 rounded-2xl text-sm ${line.startsWith('You') ? 'bg-slate-800 text-indigo-200 ml-4' : 'bg-indigo-900/30 text-indigo-100 mr-4'}`}>
                  {line}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveCoach;
