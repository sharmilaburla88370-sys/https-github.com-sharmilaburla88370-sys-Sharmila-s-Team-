
import React, { useState, useRef } from 'react';
import { analyzeImageScam } from '../services/geminiService';
import { AnalysisResult } from '../types';

const ImageScanner: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      setPreview(reader.result as string);
      setLoading(true);
      setResult(null);

      try {
        const res = await analyzeImageScam(base64, file.type);
        setResult(res);
      } catch (err) {
        alert("Failed to analyze image.");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-white">Visual Scam Check</h2>
        <p className="text-slate-400">Upload a screenshot of a text thread, a suspicious email, or a QR code. We'll extract text and visuals to hunt for malicious patterns.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`aspect-[4/3] rounded-3xl border-2 border-dashed border-slate-800 bg-slate-900/50 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 transition-all overflow-hidden relative group`}
          >
            {preview ? (
              <img src={preview} className="absolute inset-0 w-full h-full object-contain p-4" alt="Preview" />
            ) : (
              <>
                <div className="p-4 bg-slate-800 rounded-2xl mb-4 group-hover:scale-110 transition-transform">
                  <svg className="w-10 h-10 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-slate-400 font-medium">Click to upload screenshot</p>
                <p className="text-slate-500 text-sm">PNG, JPG up to 10MB</p>
              </>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange} 
            />
          </div>
          
          <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4">
            <h4 className="text-white font-semibold">Pro Tips</h4>
            <ul className="text-sm text-slate-400 space-y-2">
              <li className="flex gap-2">
                <span className="text-indigo-400">✓</span>
                Capture the sender's info in the screenshot.
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-400">✓</span>
                Ensure QR codes are clear and well-lit.
              </li>
              <li className="flex gap-2">
                <span className="text-indigo-400">✓</span>
                Include any URLs visible in the message.
              </li>
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          {loading && (
            <div className="h-full flex flex-col items-center justify-center p-12 bg-slate-900/30 rounded-3xl border border-slate-800">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg className="w-6 h-6 text-indigo-400 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                </div>
              </div>
              <p className="mt-6 text-slate-300 font-medium">Scanning visuals...</p>
              <p className="text-slate-500 text-sm">Running OCR and deepfake detection...</p>
            </div>
          )}

          {result && (
            <div className="animate-in slide-in-from-right-4 duration-500 p-8 rounded-3xl border bg-slate-900 border-slate-800">
              <div className="flex items-center gap-4 mb-8">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white ${result.isScam ? 'bg-red-500' : 'bg-emerald-500'}`}>
                  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={result.isScam ? "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" : "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"} />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">{result.isScam ? 'Alert: Potential Threat' : 'Safe to proceed'}</h3>
                  <p className="text-slate-500 text-sm">Visual Verification Complete</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-950 rounded-2xl border border-slate-800">
                  <span className="text-slate-400 text-sm">Threat Level</span>
                  <span className={`text-xl font-bold ${result.riskScore > 70 ? 'text-red-500' : 'text-emerald-500'}`}>{result.riskScore}%</span>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Findings</h4>
                  <ul className="space-y-3">
                    {result.findings.map((finding, i) => (
                      <li key={i} className="text-slate-300 text-sm flex gap-3">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0"></span>
                        {finding}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 border-t border-slate-800">
                    <p className="text-slate-400 text-sm leading-relaxed italic">
                        "{result.recommendation}"
                    </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageScanner;
