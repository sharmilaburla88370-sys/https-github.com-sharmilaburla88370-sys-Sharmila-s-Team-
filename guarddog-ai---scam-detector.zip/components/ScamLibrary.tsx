
import React from 'react';

const ScamLibrary: React.FC = () => {
  const library = [
    {
      title: 'Phishing & Smishing',
      icon: '🎣',
      desc: 'Fraudulent communications that appear to come from a reputable source (Email or SMS).',
      redFlags: ['Generic greetings', 'Urgent language', 'Strange links', 'Requests for credentials']
    },
    {
      title: 'Pig Butchering',
      icon: '🐖',
      desc: 'Long-term investment scams that build trust over weeks or months before "slaughtering" the victim.',
      redFlags: ['Unsolicited "wrong number" texts', 'Fast-moving romance', 'Crypto investment tips', 'Refusal to video call']
    },
    {
      title: 'Spoofing (Deepfake)',
      icon: '🎭',
      desc: 'Using AI to mimic the voice or face of a loved one or authority figure.',
      redFlags: ['Unusual requests for money', 'Strange background noise', 'Calls from "new numbers"', 'Emotionally charged situations']
    },
    {
      title: 'Technical Support',
      icon: '💻',
      desc: 'Scammers claim your device is infected and demand remote access or payment.',
      redFlags: ['Pop-ups with loud sirens', 'Request for remote access', 'Payment via gift cards', 'High-pressure "security" warnings']
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-extrabold text-white">Scam School</h2>
        <p className="text-slate-400 max-w-2xl mx-auto">Knowledge is your best defense. Explore our library of common AI-driven scam tactics and learn how to identify them before it's too late.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {library.map((item, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] hover:border-indigo-500/50 transition-all flex flex-col h-full">
            <div className="text-4xl mb-6">{item.icon}</div>
            <h3 className="text-2xl font-bold text-white mb-3">{item.title}</h3>
            <p className="text-slate-400 text-sm mb-6 flex-1 leading-relaxed">{item.desc}</p>
            <div className="space-y-3">
              <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">Common Red Flags</h4>
              <ul className="grid grid-cols-1 gap-2">
                {item.redFlags.map((flag, j) => (
                  <li key={j} className="text-slate-300 text-xs py-2 px-3 bg-slate-800 rounded-lg flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                    {flag}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-br from-indigo-900/20 to-slate-900 border border-indigo-500/20 p-10 rounded-[3rem] text-center space-y-6">
        <h3 className="text-2xl font-bold text-white">Think you've spotted a scam?</h3>
        <p className="text-slate-400">Reporting scams helps protect the entire community. Always report suspicious activity to your local cybercrime division or official bank channels.</p>
        <div className="flex flex-wrap justify-center gap-4 pt-4">
          <button className="px-6 py-2 bg-indigo-600 rounded-full text-white font-semibold">Report a Scam</button>
          <button className="px-6 py-2 bg-slate-800 rounded-full text-white font-semibold">Download Defense Guide</button>
        </div>
      </div>
    </div>
  );
};

export default ScamLibrary;
