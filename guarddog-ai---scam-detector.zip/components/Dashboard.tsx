
import React from 'react';

interface DashboardProps {
  onViewChange: (view: any) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onViewChange }) => {
  const stats = [
    { label: 'Scams Detected', value: '1.2k', icon: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z' },
    { label: 'Trusted Sites', value: '450+', icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
    { label: 'Protection Level', value: 'High', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
  ];

  const tools = [
    { id: 'text', title: 'Message Scanner', desc: 'Paste suspicious texts or emails to check for phishing indicators.', color: 'bg-blue-500' },
    { id: 'image', title: 'Screenshot Analysis', desc: 'Upload images of suspicious messages, QR codes, or web pages.', color: 'bg-purple-500' },
    { id: 'live', title: 'Live Voice Training', desc: 'Roleplay with an AI scammer to practice spotting social engineering.', color: 'bg-emerald-500' },
    { id: 'library', title: 'Scam School', desc: 'Learn about common scam tactics like spoofing and pig butchering.', color: 'bg-orange-500' },
  ];

  return (
    <div className="space-y-10">
      <section className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">
          Your Digital Shield Against AI Scams
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Scammers are using AI. It's time to fight back with even better AI. 
          GuardDog protects you by analyzing text, images, and voice in real-time.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex items-center gap-4">
            <div className="p-3 bg-slate-800 rounded-xl text-indigo-400">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={stat.icon} />
              </svg>
            </div>
            <div>
              <p className="text-slate-500 text-sm">{stat.label}</p>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <section>
        <h2 className="text-2xl font-bold text-white mb-6">Security Toolbox</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {tools.map((tool) => (
            <button
              key={tool.id}
              onClick={() => onViewChange(tool.id)}
              className="text-left group bg-slate-900 border border-slate-800 p-8 rounded-3xl hover:border-indigo-500/50 transition-all hover:shadow-[0_0_30px_rgba(79,70,229,0.1)] relative overflow-hidden"
            >
              <div className={`absolute top-0 right-0 w-32 h-32 ${tool.color} opacity-[0.03] blur-3xl -mr-16 -mt-16 group-hover:opacity-10 transition-opacity`}></div>
              <h3 className="text-xl font-bold text-white mb-3 flex items-center gap-2">
                {tool.title}
                <svg className="w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </h3>
              <p className="text-slate-400 leading-relaxed">{tool.desc}</p>
            </button>
          ))}
        </div>
      </section>

      <section className="bg-indigo-600/10 border border-indigo-500/20 rounded-3xl p-8 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1 space-y-4">
          <h3 className="text-2xl font-bold text-white">New to Scams?</h3>
          <p className="text-indigo-200/80">
            Check out our latest report on "Deepfake Voice Spoofing" and how to protect your family members from being targeted by AI clones.
          </p>
          <button onClick={() => onViewChange('library')} className="px-6 py-2 bg-indigo-600 text-white rounded-full font-semibold hover:bg-indigo-500 transition-colors">
            Read Security Brief
          </button>
        </div>
        <div className="w-full md:w-64 aspect-square bg-slate-950 rounded-2xl overflow-hidden shadow-2xl relative flex items-center justify-center">
             <img src="https://picsum.photos/400/400?random=1" className="absolute inset-0 w-full h-full object-cover opacity-50" alt="Cybersecurity" />
             <div className="relative text-indigo-400 animate-pulse">
                <svg className="w-20 h-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0012 21a9.994 9.994 0 0010-10V7a2 2 0 00-2-2H4a2 2 0 00-2 2v10c0 .315.012.628.035.938l.49.854a.5.5 0 00.43.245H4m12 0a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
             </div>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
