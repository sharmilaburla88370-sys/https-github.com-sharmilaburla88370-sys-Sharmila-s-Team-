
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { AnalysisResult, ScamCategory } from "../types";

const API_KEY = process.env.API_KEY || "";

export const analyzeTextScam = async (text: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following message for scam potential: "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          riskScore: { type: Type.NUMBER, description: "Risk score from 0 to 100" },
          category: { type: Type.STRING, description: "Scam category (PHISHING, SPOOFING, URGENCY, SOCIAL_ENGINEERING, FINANCIAL_FRAUD, LEGITIMATE)" },
          findings: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of red flags or observations" },
          recommendation: { type: Type.STRING, description: "What the user should do" },
          isScam: { type: Type.BOOLEAN, description: "Final verdict if it's likely a scam" }
        },
        required: ["riskScore", "category", "findings", "recommendation", "isScam"]
      }
    }
  });

  try {
    const result = JSON.parse(response.text.trim()) as AnalysisResult;
    return result;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Analysis failed");
  }
};

export const analyzeImageScam = async (base64Image: string, mimeType: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType } },
        { text: "Analyze this image (could be a text message screenshot, QR code, or suspicious email) for scam indicators." }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          riskScore: { type: Type.NUMBER },
          category: { type: Type.STRING },
          findings: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendation: { type: Type.STRING },
          isScam: { type: Type.BOOLEAN }
        },
        required: ["riskScore", "category", "findings", "recommendation", "isScam"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim()) as AnalysisResult;
  } catch (e) {
    throw new Error("Image analysis failed");
  }
};

export const groundScamQuery = async (query: string): Promise<any> => {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Is this phone number, email, or company associated with known scams or data breaches? ${query}`,
        config: {
            tools: [{ googleSearch: {} }]
        }
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
        title: chunk.web?.title,
        uri: chunk.web?.uri
    })).filter((s: any) => s.title && s.uri);

    return {
        text: response.text,
        sources: sources || []
    };
};
